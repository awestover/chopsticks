The chopsticks game


